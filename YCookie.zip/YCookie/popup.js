import Ycopy from "./Ycopy/index.js";
import Yclear from "./Yclear/index.js";
import Ypaste from "./Ypaste/index.js";

(function () {
  Ycopy();
  Yclear();
  Ypaste();
})();
