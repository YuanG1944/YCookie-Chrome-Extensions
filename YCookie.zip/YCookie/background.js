// chrome.runtime.onInstalled.addListener(() => {
//   console.log('Open cookie!');
  
// });

// chrome.cookies.getAllCookieStores(
//   ( cookieStores) => {
//     console.log('cookie store', cookieStores);
//   }
// )

// chrome.cookies.getAll('domain', (cookies) => {
//   console.log('cookies-->', cookies);
// })